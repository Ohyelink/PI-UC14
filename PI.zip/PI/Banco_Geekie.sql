create table Pedido (
data_pedido date,
valor_total decimal (6,2),
itens int,
ID int (11) NOT NULL auto_increment,
primary key (ID)
) default charset = utf8;
