<?php

$hostname = "localhost";
$bandodedados = "banco";
$usuario = "root"
$senha = "admin";

$mysqli = new mysqli($hostname, $bandodedados, $usuario, $senha);
if ($mysqli->connect_errno) {
    echo"Falha ao conectar: (" .$mysqli->connect_errno . ") " .$mysqli->connect_errno;
}
else {
    echo"Conexao bem sucedida" . connect_errno ;
}
    
?>