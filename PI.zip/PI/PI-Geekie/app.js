const mobileMenu = document.querySelector('.mobile-menu');
const navlist = document.querySelector('li');
const button = document.querySelector('.mobile-menu');

button.addEventListener('click',() =>  {
    mobileMenu.classList.toggle('.active');
});

